﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TriangleSolver;
using NUnit.Framework;

namespace Testing
{
    [TestFixture]
    public class TestTriangle
    {
        Triangle objectTesting = new Triangle();

        [Test]
        public void AnalyzeTriangle_Input1and1and1_EquilateralTriangle()
        {
            //Arrange
            int sideOne = 1;
            int sideTwo = 1;
            int sideThree = 1;

            string expected = "Based on all sides being equal, the type of triangle is an EQUILATERAL";

            //Act
            string actual = objectTesting.AnalyzeTriangle(sideOne, sideTwo, sideThree);

            //Assert
            Assert.AreEqual(expected, actual);
        }

        
    }
}
