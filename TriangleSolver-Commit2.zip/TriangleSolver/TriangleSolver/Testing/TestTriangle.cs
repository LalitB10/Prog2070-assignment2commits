﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TriangleSolver;
using NUnit.Framework;

namespace Testing
{
    [TestFixture]
    public class TestTriangle
    {
        Triangle objectTesting = new Triangle();

        [Test]
        public void AnalyzeTriangle_Input1and1and1_EquilateralTriangle()
        {
            //Arrange
            int sideOne = 1;
            int sideTwo = 1;
            int sideThree = 1;

            string expected = "Based on all sides being equal, the type of triangle is an EQUILATERAL";

            //Act
            string actual = objectTesting.AnalyzeTriangle(sideOne, sideTwo, sideThree);

            //Assert
            Assert.AreEqual(expected, actual);
        }

        [Test]
        public void AnalyzeTriangle_Input3and2and2_IsoscelesTriangle1()
        {
            //Arrange
            int sideOne = 3;
            int sideTwo = 2;
            int sideThree = 2;

            string expected = "Based on two sides being equal, the type of triangle is an ISOSCELES";

            //Act
            string actual = objectTesting.AnalyzeTriangle(sideOne, sideTwo, sideThree);

            //Assert
            Assert.AreEqual(expected, actual);
        }

        [Test]
        public void AnalyzeTriangle_Input3and4and3_IsoscelesTriangle2()
        {
            //Arrange
            int sideOne = 3;
            int sideTwo = 4;
            int sideThree = 3;

            string expected = "Based on two sides being equal, the type of triangle is an ISOSCELES";

            //Act
            string actual = objectTesting.AnalyzeTriangle(sideOne, sideTwo, sideThree);

            //Assert
            Assert.AreEqual(expected, actual);
        }

        [Test]
        public void AnalyzeTriangle_Input4and5and4_IsoscelesTriangle3()
        {
            //Arrange
            int sideOne = 4;
            int sideTwo = 5;
            int sideThree = 4;

            string expected = "Based on two sides being equal, the type of triangle is an ISOSCELES";

            //Act
            string actual = objectTesting.AnalyzeTriangle(sideOne, sideTwo, sideThree);

            //Assert
            Assert.AreEqual(expected, actual);
        }
    }
}
