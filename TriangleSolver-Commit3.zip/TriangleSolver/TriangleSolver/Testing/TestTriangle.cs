﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TriangleSolver;
using NUnit.Framework;

namespace Testing
{
    [TestFixture]
    public class TestTriangle
    {
        Triangle objectTesting = new Triangle();

        [Test]
        public void AnalyzeTriangle_Input1and1and1_EquilateralTriangle()
        {
            //Arrange
            int sideOne = 1;
            int sideTwo = 1;
            int sideThree = 1;

            string expected = "Based on all sides being equal, the type of triangle is an EQUILATERAL";

            //Act
            string actual = objectTesting.AnalyzeTriangle(sideOne, sideTwo, sideThree);

            //Assert
            Assert.AreEqual(expected, actual);
        }

        [Test]
        public void AnalyzeTriangle_Input3and2and2_IsoscelesTriangle1()
        {
            //Arrange
            int sideOne = 3;
            int sideTwo = 2;
            int sideThree = 2;

            string expected = "Based on two sides being equal, the type of triangle is an ISOSCELES";

            //Act
            string actual = objectTesting.AnalyzeTriangle(sideOne, sideTwo, sideThree);

            //Assert
            Assert.AreEqual(expected, actual);
        }

        [Test]
        public void AnalyzeTriangle_Input3and4and3_IsoscelesTriangle2()
        {
            //Arrange
            int sideOne = 3;
            int sideTwo = 4;
            int sideThree = 3;

            string expected = "Based on two sides being equal, the type of triangle is an ISOSCELES";

            //Act
            string actual = objectTesting.AnalyzeTriangle(sideOne, sideTwo, sideThree);

            //Assert
            Assert.AreEqual(expected, actual);
        }

        [Test]
        public void AnalyzeTriangle_Input4and5and4_IsoscelesTriangle3()
        {
            //Arrange
            int sideOne = 4;
            int sideTwo = 5;
            int sideThree = 4;

            string expected = "Based on two sides being equal, the type of triangle is an ISOSCELES";

            //Act
            string actual = objectTesting.AnalyzeTriangle(sideOne, sideTwo, sideThree);

            //Assert
            Assert.AreEqual(expected, actual);
        }

        [Test]

        public void AnalyzeTriangle_Input2and3and4_ScaleneTriangle1()
        {
            //Arrange
            int sideOne = 2;
            int sideTwo = 3;
            int sideThree = 4;

            string expected = "Based on all three sides being different, the type of triangle is a SCALENE";

            //Act
            string actual = objectTesting.AnalyzeTriangle(sideOne, sideTwo, sideThree);

            //Assert
            Assert.AreEqual(expected, actual);
        }

        [Test]

        public void AnalyzeTriangle_Input5and6and7_ScaleneTriangle2()
        {
            //Arrange
            int sideOne = 5;
            int sideTwo = 6;
            int sideThree = 7;

            string expected = "Based on all three sides being different, the type of triangle is a SCALENE";

            //Act
            string actual = objectTesting.AnalyzeTriangle(sideOne, sideTwo, sideThree);

            //Assert
            Assert.AreEqual(expected, actual);
        }

        [Test]

        public void AnalyzeTriangle_Input8and9and10_ScaleneTriangle3()
        {
            //Arrange
            int sideOne = 8;
            int sideTwo = 9;
            int sideThree = 10;

            string expected = "Based on all three sides being different, the type of triangle is a SCALENE";

            //Act
            string actual = objectTesting.AnalyzeTriangle(sideOne, sideTwo, sideThree);

            //Assert
            Assert.AreEqual(expected, actual);
        }

        [Test]

        public void AnalyzeTriangle_Input12and13and14_ScaleneTriangle4()
        {
            //Arrange
            int sideOne = 12;
            int sideTwo = 13;
            int sideThree = 14;

            string expected = "Based on all three sides being different, the type of triangle is a SCALENE";

            //Act
            string actual = objectTesting.AnalyzeTriangle(sideOne, sideTwo, sideThree);

            //Assert
            Assert.AreEqual(expected, actual);
        }

        [Test]
        public void AnalyzeTriangle_Input15and16and17_ScaleneTriangle5()
        {
            //Arrange
            int sideOne = 15;
            int sideTwo = 16;
            int sideThree = 17;

            string expected = "Based on all three sides being different, the type of triangle is a SCALENE";

            //Act
            string actual = objectTesting.AnalyzeTriangle(sideOne, sideTwo, sideThree);

            //Assert
            Assert.AreEqual(expected, actual);
        }

        [Test]

        public void AnalyzeTriangle_Input0and1and2_ZeroLengthTriangle1()
        {
            //Arrange
            int sideOne = 0;
            int sideTwo = 1;
            int sideThree = 2;

            string expected = "At least one side of your triangle has a zero length and is thus invalid";

            //Act
            string actual = objectTesting.AnalyzeTriangle(sideOne, sideTwo, sideThree);

            //Assert
            Assert.AreEqual(expected, actual);
        }

        [Test]

        public void AnalyzeTriangle_Input0and1and0_ZeroLengthTriangle2()
        {
            //Arrange
            int sideOne = 0;
            int sideTwo = 1;
            int sideThree = 0;

            string expected = "At least one side of your triangle has a zero length and is thus invalid";

            //Act
            string actual = objectTesting.AnalyzeTriangle(sideOne, sideTwo, sideThree);

            //Assert
            Assert.AreEqual(expected, actual);
        }


        [Test]

        public void AnalyzeTriangle_Input0and0and0_ZeroLengthTriangle3()
        {
            //Arrange
            int sideOne = 0;
            int sideTwo = 0;
            int sideThree = 0;

            string expected = "At least one side of your triangle has a zero length and is thus invalid";

            //Act
            string actual = objectTesting.AnalyzeTriangle(sideOne, sideTwo, sideThree);

            //Assert
            Assert.AreEqual(expected, actual);
        }

        [Test]

        public void AnalyzeTriangle_Inputnegative1and2andnegative3_InvalidResponseTriangle1()
        {
            //Arrange
            int sideOne = -1;
            int sideTwo = 2;
            int sideThree = -3;

            string expected = "Based on the values entered, the triangle is INVALID";

            //Act
            string actual = objectTesting.AnalyzeTriangle(sideOne, sideTwo, sideThree);

            //Assert
            Assert.AreEqual(expected, actual);
        }

        [Test]

        public void AnalyzeTriangle_Inputnegative2andnegative3and4_InvalidResponseTriangle2()
        {
            //Arrange
            int sideOne = -2;
            int sideTwo = -3;
            int sideThree = 4;

            string expected = "Based on the values entered, the triangle is INVALID";

            //Act
            string actual = objectTesting.AnalyzeTriangle(sideOne, sideTwo, sideThree);

            //Assert
            Assert.AreEqual(expected, actual);
        }

        [Test]

        public void AnalyzeTriangle_Input3andnegative4andnegative5_InvalidResponseTriangle3()
        {
            //Arrange
            int sideOne = 3;
            int sideTwo = -4;
            int sideThree = -5;

            string expected = "Based on the values entered, the triangle is INVALID";

            //Act
            string actual = objectTesting.AnalyzeTriangle(sideOne, sideTwo, sideThree);

            //Assert
            Assert.AreEqual(expected, actual);
        }
    }
}
